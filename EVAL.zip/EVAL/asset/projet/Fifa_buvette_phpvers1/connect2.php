<?php
$titre='Accueil' ;

$nav='<li><a href="accueil.php">Accueil</a></li>
<li><a href="">Statistiques</a></li>
<li><a href="">Recherche Membres</a></li>
<li><a href="">Calendrier</a></li>
<li><a href="">Statistiques</a></li>
<li><a href="">Admin</a></li>';

$user='root';
$pass='';

?>