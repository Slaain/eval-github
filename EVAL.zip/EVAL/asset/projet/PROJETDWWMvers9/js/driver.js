
$(function(){
$("#container-user").hide();
$( "#ad" ).click(function() {
 $( "#container-user" ).slideToggle( "slow" );
  });
});