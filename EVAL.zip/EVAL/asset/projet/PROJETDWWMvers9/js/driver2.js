
$(function(){
  $("#end").hide();
$( "#start" ).click(function() {
  $( "#end" ).toggle( "slow" );
  });
});
